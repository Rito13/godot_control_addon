#ifndef REVISED_BUTTON_H
#define REVISED_BUTTON_H

#include "better_scroll.h"
#include <godot_cpp/classes/v_scroll_bar.hpp>
#include <godot_cpp/classes/button.hpp>
#include <godot_cpp/classes/timer.hpp>
#include <godot_cpp/classes/rich_text_label.hpp>

namespace godot {

class RevisedButton : public Button {
	GDCLASS(RevisedButton, Button)

private:
	double time_passed;
	double amplitude;
	String better_text = "Text";
	double old_height = 0;
	//Internal children
	AutoScroll *scroll;
	Timer *idle_time_timer;
	Control *text_parent;
	RichTextLabel *text_container;
	double adaptable_speed = 100;
	//Aligment functions and variables
	HorizontalAlignment h_text_alignment = HORIZONTAL_ALIGNMENT_CENTER;
	VerticalAlignment v_text_alignment = VERTICAL_ALIGNMENT_TOP;
	String _h_bbcode = "[center]";
	String _v_bbcode = "";
	void update_text_horizontal_alignment();
	void update_text_vertical_alignment();
	bool scrolling = false;

protected:
	static void _bind_methods();

public:
	RevisedButton();
	~RevisedButton();

	void _process(double delta);
	void on_timer_out();

	//Amplitude property
	void set_amplitude(const double p_amplitude);
	double get_amplitude() const;
	//Text property
	void set_text(const String p_text);
	String get_text() const;
	void update_text();
	//Aligment property
	VerticalAlignment get_v_text_alignment() const;
	void set_v_text_alignment(const VerticalAlignment p_alignment);
	//Autowrap property
	TextServer::AutowrapMode get_text_autowrap() const;
	void set_text_autowrap(const TextServer::AutowrapMode p_autowrap);
	//Adaptable Speed property
	void set_adaptable_speed(double p_speed);
	double get_adaptable_speed();
};

}

#endif
